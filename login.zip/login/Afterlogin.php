<html>
<head></head>

<body>

<?php 

 echo $reslt;

?>

</body>
</html>